import * as THREE from 'three';

const SCALE = 0.05;
const TAU = Math.PI * 2;
const UP = new THREE.Vector3(0, 1, 0);
const CLASS_COLORS = { guardian: '#f1b45b', ranger: '#6fd7ae', oracle: '#8ab8ff' };
const STYLES = {
  minotaur: { color: '#df704b', ground: '#27322b', grid: '#3e493d', sky: '#101a1c', fog: '#172326', weather: '#e58a50' },
  anubis: { color: '#d5ae55', ground: '#61513a', grid: '#7a6747', sky: '#30261e', fog: '#66503a', weather: '#d5b77c' },
  fenrir: { color: '#69a9d6', ground: '#6f878c', grid: '#8ba0a5', sky: '#102433', fog: '#3e5e6d', weather: '#d9f4ff' }
};

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const lerp = (a, b, t) => a + (b - a) * t;
function lerpAngle(a, b, t) {
  const delta = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + delta * t;
}
function to3(x, y, height = 0) {
  return new THREE.Vector3((x - 800) * SCALE, height, (y - 450) * SCALE);
}
function seededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value += 0x6D2B79F5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function standard(color, options = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: options.roughness ?? 0.76,
    metalness: options.metalness ?? 0.08,
    flatShading: options.flatShading ?? true,
    emissive: options.emissive || '#000000',
    emissiveIntensity: options.emissiveIntensity || 0,
    transparent: Boolean(options.transparent),
    opacity: options.opacity ?? 1,
    side: options.side || THREE.FrontSide
  });
}
function basic(color, options = {}) {
  return new THREE.MeshBasicMaterial({
    color,
    transparent: options.transparent ?? true,
    opacity: options.opacity ?? 1,
    depthWrite: options.depthWrite ?? false,
    side: options.side || THREE.DoubleSide,
    blending: options.blending || THREE.NormalBlending
  });
}
function addMesh(parent, geometry, material, position = [0, 0, 0], rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(...position);
  mesh.rotation.set(...rotation);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
function addBox(parent, size, position, material, rotation) {
  return addMesh(parent, new THREE.BoxGeometry(...size), material, position, rotation);
}
function addCylinder(parent, top, bottom, height, segments, position, material, rotation) {
  return addMesh(parent, new THREE.CylinderGeometry(top, bottom, height, segments), material, position, rotation);
}
function addCapsule(parent, radius, length, position, material, rotation = [0, 0, 0]) {
  return addMesh(parent, new THREE.CapsuleGeometry(radius, length, 4, 8), material, position, rotation);
}
function addSphere(parent, radius, position, material, detail = 1) {
  return addMesh(parent, new THREE.IcosahedronGeometry(radius, detail), material, position);
}
function disposeObject(object) {
  object.traverse((child) => {
    if (child.geometry) child.geometry.dispose();
    if (child.material) {
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      materials.forEach((material) => {
        if (material.map) material.map.dispose();
        material.dispose();
      });
    }
  });
}
function clearGroup(group) {
  while (group.children.length) {
    const child = group.children[0];
    group.remove(child);
    disposeObject(child);
  }
}
function floorRing(inner, outer, color, opacity = 0.3, segments = 64) {
  const ring = new THREE.Mesh(new THREE.RingGeometry(inner, outer, segments), basic(color, { opacity }));
  ring.rotation.x = -Math.PI / 2;
  ring.castShadow = false;
  ring.receiveShadow = false;
  return ring;
}

export class GameRenderer {
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    this.lowQuality = Boolean(options.lowQuality);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !this.lowQuality, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(this.lowQuality ? 1 : Math.min(1.75, window.devicePixelRatio || 1));
    this.renderer.shadowMap.enabled = !this.lowQuality;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.24;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(STYLES.minotaur.sky);
    this.scene.fog = new THREE.FogExp2(STYLES.minotaur.fog, 0.013);
    this.camera = new THREE.PerspectiveCamera(61, 1, 0.1, 240);
    this.cameraBase = new THREE.Vector3(0, 7, 12);
    this.cameraLook = new THREE.Vector3(0, 1.5, 0);
    this.camera.position.copy(this.cameraBase);
    this.camera.lookAt(this.cameraLook);
    this.cameraInitialized = false;
    this.cameraAway = new THREE.Vector3(0, 0, 1);
    this.lockOn = true;
    this.orbitYaw = 0;
    this.orbitPitch = 0;
    this.zoom = 11.2;
    this.hitPulse = 0;
    this.shake = 0;

    this.environment = new THREE.Group();
    this.dynamic = new THREE.Group();
    this.effectLayer = new THREE.Group();
    this.scene.add(this.environment, this.dynamic, this.effectLayer);
    this.players = new Map();
    this.projectiles = new Map();
    this.telegraphs = new Map();
    this.effects = [];
    this.bossRecord = null;
    this.worldKey = '';
    this.weather = null;

    this.hemisphere = new THREE.HemisphereLight('#a8c5d0', '#273027', 2.25);
    this.scene.add(this.hemisphere);
    this.sun = new THREE.DirectionalLight('#ffe4c4', 3.1);
    this.sun.position.set(-18, 34, 17);
    this.sun.castShadow = !this.lowQuality;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.left = -48;
    this.sun.shadow.camera.right = 48;
    this.sun.shadow.camera.top = 40;
    this.sun.shadow.camera.bottom = -40;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 100;
    this.sun.shadow.bias = -0.00035;
    this.scene.add(this.sun);

    this.raycaster = new THREE.Raycaster();
    this.groundPlane = new THREE.Plane(UP, 0);
    this.pointer = new THREE.Vector2();
    this.aimReticle = floorRing(0.34, 0.43, '#f1e7d3', 0.75, 32);
    this.aimReticle.visible = false;
    this.scene.add(this.aimReticle);
    this.resize(window.innerWidth, window.innerHeight);
  }

  resize(width, height) {
    this.renderer.setPixelRatio(this.lowQuality ? 1 : Math.min(1.75, window.devicePixelRatio || 1));
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
  }

  resetWorld(game) {
    clearGroup(this.environment);
    clearGroup(this.dynamic);
    clearGroup(this.effectLayer);
    this.players.clear();
    this.projectiles.clear();
    this.telegraphs.clear();
    this.effects = [];
    this.bossRecord = null;
    this.weather = null;
    this.cameraInitialized = false;
    this.cameraAway.set(0, 0, 1);
    this.lockOn = true;
    this.orbitYaw = 0;
    this.orbitPitch = 0;
    this.worldKey = `${game.bossId}-${game.decorSeed}`;
    this.buildArena(game);
  }

  buildArena(game) {
    const style = STYLES[game.bossId];
    const random = seededRandom(game.decorSeed);
    this.scene.background = new THREE.Color(style.sky);
    this.scene.fog = new THREE.FogExp2(style.fog, game.bossId === 'anubis' ? 0.015 : 0.0115);
    this.hemisphere.color.set(game.bossId === 'fenrir' ? '#b7e1f2' : game.bossId === 'anubis' ? '#f0c98e' : '#b4ced1');
    this.hemisphere.groundColor.set(style.ground);
    this.sun.color.set(game.bossId === 'fenrir' ? '#b9dafa' : game.bossId === 'anubis' ? '#ffd096' : '#d5e3db');
    this.sun.intensity = game.bossId === 'anubis' ? 3.5 : game.bossId === 'fenrir' ? 2.45 : 3.25;
    this.hemisphere.intensity = game.bossId === 'fenrir' ? 1.7 : 2.2;

    const groundTexture = this.makeGroundTexture(game, random);
    const groundMaterial = new THREE.MeshStandardMaterial({ map: groundTexture, roughness: 0.96, metalness: 0, color: '#ffffff' });
    const floor = addBox(this.environment, [82, 0.55, 47], [0, -0.34, 0], groundMaterial);
    floor.castShadow = false;
    floor.receiveShadow = true;

    const outerMaterial = standard(game.bossId === 'fenrir' ? '#657d83' : game.bossId === 'anubis' ? '#4b3c2b' : '#111c1b');
    const outer = addMesh(this.environment, new THREE.PlaneGeometry(220, 170), outerMaterial, [0, -0.64, 0], [-Math.PI / 2, 0, 0]);
    outer.castShadow = false;

    const borderMaterial = standard(game.bossId === 'anubis' ? '#766345' : game.bossId === 'fenrir' ? '#61777d' : '#3e4941');
    addBox(this.environment, [83, 0.7, 0.65], [0, 0.05, -23.4], borderMaterial);
    addBox(this.environment, [83, 0.7, 0.65], [0, 0.05, 23.4], borderMaterial);
    addBox(this.environment, [0.65, 0.7, 46], [-41.2, 0.05, 0], borderMaterial);
    addBox(this.environment, [0.65, 0.7, 46], [41.2, 0.05, 0], borderMaterial);

    for (const radius of [8, 14, 21]) {
      const ring = floorRing(radius - 0.045, radius + 0.045, style.color, radius === 8 ? 0.24 : 0.1);
      ring.position.y = 0.015;
      this.environment.add(ring);
    }
    for (let i = 0; i < 16; i += 1) {
      const angle = (i / 16) * TAU;
      const rune = addBox(this.environment, [0.65, 0.035, 0.16], [Math.cos(angle) * 13.8, 0.025, Math.sin(angle) * 13.8], basic(style.color, { opacity: 0.24 }), [0, -angle, 0]);
      rune.castShadow = false;
    }

    if (game.bossId === 'minotaur') this.buildGreekArena(random);
    else if (game.bossId === 'anubis') this.buildEgyptArena(random);
    else this.buildNorseArena(random);
    if (!this.lowQuality) this.createWeather(game.bossId, random);
  }

  makeGroundTexture(game, random) {
    const style = STYLES[game.bossId];
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 576;
    const context = canvas.getContext('2d');
    context.fillStyle = style.ground;
    context.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < (this.lowQuality ? 3200 : 8500); i += 1) {
      const alpha = random() * 0.11;
      context.fillStyle = random() > 0.5 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
      const size = 1 + random() * 3;
      context.fillRect(random() * canvas.width, random() * canvas.height, size, size);
    }

    context.strokeStyle = style.grid;
    context.globalAlpha = game.bossId === 'fenrir' ? 0.25 : 0.48;
    context.lineWidth = 2;
    const tile = game.bossId === 'anubis' ? 92 : 80;
    for (let x = 0; x < canvas.width; x += tile) {
      context.beginPath(); context.moveTo(x, 0); context.lineTo(x, canvas.height); context.stroke();
    }
    for (let y = 0; y < canvas.height; y += tile) {
      context.beginPath(); context.moveTo(0, y); context.lineTo(canvas.width, y); context.stroke();
    }
    context.globalAlpha = 0.25;
    context.strokeStyle = style.color;
    for (let i = 0; i < 28; i += 1) {
      const x = random() * canvas.width;
      const y = random() * canvas.height;
      const size = 6 + random() * 16;
      context.beginPath();
      context.moveTo(x - size, y + size);
      context.lineTo(x, y - size);
      context.lineTo(x + size, y + size);
      context.moveTo(x - size / 2, y);
      context.lineTo(x + size / 2, y);
      context.stroke();
    }
    context.globalAlpha = 1;
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    return texture;
  }

  buildGreekArena(random) {
    const marble = standard('#677068', { roughness: 0.9 });
    const darkMarble = standard('#424e47');
    const positions = [];
    for (let x = -36; x <= 36; x += 12) {
      positions.push([x, -26], [x, 26]);
    }
    for (let z = -14; z <= 14; z += 14) positions.push([-45, z], [45, z]);
    positions.forEach(([x, z], index) => {
      const group = new THREE.Group();
      group.position.set(x, 0, z);
      const height = index % 4 === 0 ? 2.5 + random() * 1.5 : 5.5;
      addCylinder(group, 0.62, 0.78, height, 10, [0, height / 2, 0], marble);
      addBox(group, [1.8, 0.35, 1.8], [0, 0.18, 0], darkMarble);
      if (height > 4) addBox(group, [1.65, 0.38, 1.65], [0, height, 0], marble);
      group.rotation.y = random() * 0.3;
      this.environment.add(group);
    });

    const bronze = standard('#5f4530', { metalness: 0.45 });
    const flame = basic('#ff8a45', { opacity: 0.9, blending: THREE.AdditiveBlending });
    [[-32, -19], [32, 19]].forEach(([x, z]) => {
      addCylinder(this.environment, 0.7, 0.4, 0.5, 8, [x, 1.1, z], bronze);
      addCylinder(this.environment, 0.15, 0.25, 1.8, 8, [x, 0.2, z], bronze);
      const fire = addMesh(this.environment, new THREE.ConeGeometry(0.45, 1.4, 7), flame, [x, 2.05, z]);
      fire.castShadow = false;
      const light = new THREE.PointLight('#ff8442', 35, 17, 2);
      light.position.set(x, 2.6, z);
      this.environment.add(light);
    });
  }

  buildEgyptArena(random) {
    const sandstone = standard('#8a7350');
    const dark = standard('#4a4133');
    const glow = standard('#276d68', { emissive: '#43c7b6', emissiveIntensity: 1.3 });
    const positions = [[-37, -20], [37, -20], [-37, 20], [37, 20], [-44, 0], [44, 0]];
    positions.forEach(([x, z], index) => {
      const group = new THREE.Group();
      group.position.set(x, 0, z);
      addCylinder(group, 0.38, 0.78, 6.5, 4, [0, 3.25, 0], sandstone, [0, Math.PI / 4, 0]);
      addMesh(group, new THREE.ConeGeometry(0.55, 1.5, 4), sandstone, [0, 7.1, 0], [0, Math.PI / 4, 0]);
      addBox(group, [0.12, 2.4, 0.06], [0, 3.5, 0.57], glow);
      group.rotation.y = index * 0.35;
      this.environment.add(group);
    });
    [[-61, -38, 12], [59, -43, 16], [-68, 34, 9]].forEach(([x, z, size]) => {
      const pyramid = addMesh(this.environment, new THREE.ConeGeometry(size, size * 0.75, 4), dark, [x, size * 0.36 - 0.5, z], [0, Math.PI / 4, 0]);
      pyramid.castShadow = false;
    });
    for (let i = 0; i < 18; i += 1) {
      const stone = addBox(this.environment, [0.7 + random() * 1.6, 0.4 + random(), 0.7 + random() * 1.4], [(random() - 0.5) * 105, 0, (random() > 0.5 ? 1 : -1) * (25 + random() * 15)], sandstone, [random(), random(), random()]);
      stone.castShadow = false;
    }
  }

  buildNorseArena(random) {
    const trunk = standard('#3a3430');
    const needles = standard('#1d3d40');
    const snow = standard('#b8cbce');
    const rock = standard('#526870');
    for (let i = 0; i < (this.lowQuality ? 16 : 30); i += 1) {
      const side = i % 2 ? 1 : -1;
      const x = (random() - 0.5) * 105;
      const z = side * (27 + random() * 23);
      const scale = 0.75 + random() * 0.85;
      const tree = new THREE.Group();
      tree.position.set(x, 0, z);
      addCylinder(tree, 0.18, 0.25, 2.5 * scale, 7, [0, 1.25 * scale, 0], trunk);
      for (let tier = 0; tier < 3; tier += 1) {
        addMesh(tree, new THREE.ConeGeometry((1.65 - tier * 0.32) * scale, 2.5 * scale, 7), needles, [0, (2.2 + tier * 1.15) * scale, 0]);
        addMesh(tree, new THREE.ConeGeometry((1.55 - tier * 0.32) * scale, 0.18, 7), snow, [0, (3.35 + tier * 1.15) * scale, 0]);
      }
      this.environment.add(tree);
    }
    for (let i = 0; i < 22; i += 1) {
      const stone = addMesh(this.environment, new THREE.DodecahedronGeometry(0.6 + random() * 1.3, 0), rock, [(random() - 0.5) * 100, 0.1, (random() > 0.5 ? 1 : -1) * (24 + random() * 18)], [random(), random(), random()]);
      stone.scale.y = 0.55 + random() * 0.7;
    }
    for (let i = 0; i < 9; i += 1) {
      const angle = (i / 9) * TAU;
      const radius = 78 + random() * 20;
      const height = 18 + random() * 20;
      const mountain = addMesh(this.environment, new THREE.ConeGeometry(13 + random() * 9, height, 5), rock, [Math.cos(angle) * radius, height / 2 - 1, Math.sin(angle) * radius]);
      mountain.castShadow = false;
      addMesh(this.environment, new THREE.ConeGeometry(5 + random() * 4, height * 0.35, 5), snow, [Math.cos(angle) * radius, height * 0.82, Math.sin(angle) * radius]);
    }
  }

  createWeather(bossId, random) {
    const count = bossId === 'anubis' ? 360 : 480;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = (random() - 0.5) * 100;
      positions[i * 3 + 1] = random() * 18;
      positions[i * 3 + 2] = (random() - 0.5) * 65;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: STYLES[bossId].weather,
      size: bossId === 'fenrir' ? 2.1 : 1.6,
      sizeAttenuation: false,
      transparent: true,
      opacity: bossId === 'anubis' ? 0.35 : 0.62,
      depthWrite: false,
      blending: bossId === 'minotaur' ? THREE.AdditiveBlending : THREE.NormalBlending
    });
    const points = new THREE.Points(geometry, material);
    this.environment.add(points);
    this.weather = { points, positions, count, bossId };
  }

  createPlayerRecord(player) {
    const group = new THREE.Group();
    const model = this.createPlayerModel(player.classId);
    group.add(model.root);
    const localRing = floorRing(0.83, 0.89, '#ffffff', 0.55, 40);
    localRing.position.y = 0.035;
    group.add(localRing);
    const reviveRing = floorRing(0.95, 1.06, '#75daa9', 0.85, 40);
    reviveRing.position.y = 0.045;
    reviveRing.visible = false;
    group.add(reviveRing);
    const shield = addSphere(model.root, 1.18, [0, 1.15, 0], basic('#f4cf78', { opacity: 0.14, blending: THREE.AdditiveBlending }), 2);
    shield.visible = false;
    shield.castShadow = false;
    const label = this.createLabel(player.name, CLASS_COLORS[player.classId]);
    label.sprite.position.set(0, 2.85, 0);
    group.add(label.sprite);
    group.position.copy(to3(player.x, player.y));
    this.dynamic.add(group);
    const record = { group, model, label, localRing, reviveRing, shield, walk: 0, lastPosition: group.position.clone(), labelKey: '' };
    this.players.set(player.id, record);
    return record;
  }

  createPlayerModel(classId) {
    const root = new THREE.Group();
    const color = CLASS_COLORS[classId];
    const main = standard(color, { metalness: classId === 'guardian' ? 0.35 : 0.08 });
    const dark = standard(classId === 'oracle' ? '#202d47' : classId === 'ranger' ? '#19382f' : '#363b39');
    const leather = standard('#443a31');
    const skin = standard('#a97c62');
    const glow = standard(color, { emissive: color, emissiveIntensity: 1.4 });

    const leftLeg = new THREE.Group();
    const rightLeg = new THREE.Group();
    leftLeg.position.set(-0.22, 0.9, 0);
    rightLeg.position.set(0.22, 0.9, 0);
    root.add(leftLeg, rightLeg);
    addCapsule(leftLeg, 0.16, 0.5, [0, -0.42, 0], dark);
    addCapsule(rightLeg, 0.16, 0.5, [0, -0.42, 0], dark);
    addBox(leftLeg, [0.32, 0.18, 0.52], [0, -0.82, 0.1], leather);
    addBox(rightLeg, [0.32, 0.18, 0.52], [0, -0.82, 0.1], leather);

    if (classId === 'oracle') {
      addMesh(root, new THREE.ConeGeometry(0.68, 1.5, 8), dark, [0, 0.85, 0]);
      addCylinder(root, 0.43, 0.55, 0.85, 8, [0, 1.42, 0], main);
    } else if (classId === 'guardian') {
      addBox(root, [1.02, 0.95, 0.66], [0, 1.35, 0], main);
      addBox(root, [0.72, 0.58, 0.72], [0, 1.28, 0.05], dark);
      addSphere(root, 0.35, [-0.64, 1.67, 0], main);
      addSphere(root, 0.35, [0.64, 1.67, 0], main);
    } else {
      addCylinder(root, 0.36, 0.48, 1.05, 7, [0, 1.35, 0], dark);
      addBox(root, [0.72, 0.23, 0.55], [0, 1.65, 0], main);
      addBox(root, [0.27, 0.85, 0.25], [-0.25, 1.35, -0.4], leather, [0, 0, -0.2]);
    }

    addSphere(root, 0.32, [0, 2.05, 0], skin, 1);
    if (classId === 'guardian') {
      addCylinder(root, 0.35, 0.38, 0.4, 7, [0, 2.13, 0], main);
      addBox(root, [0.12, 0.4, 0.55], [0, 2.43, -0.05], glow);
      addBox(root, [0.1, 0.12, 0.36], [0, 2.06, 0.33], dark);
    } else if (classId === 'ranger') {
      addMesh(root, new THREE.ConeGeometry(0.47, 0.75, 7), dark, [0, 2.26, -0.05]);
      addBox(root, [0.4, 0.13, 0.08], [0, 2.08, 0.31], main);
    } else {
      addSphere(root, 0.39, [0, 2.12, -0.05], dark, 1);
      addSphere(root, 0.28, [0, 2.08, 0.17], skin, 1);
      const circlet = addMesh(root, new THREE.TorusGeometry(0.33, 0.035, 5, 16), glow, [0, 2.14, 0], [Math.PI / 2, 0, 0]);
      circlet.castShadow = false;
    }

    const eyeMaterial = standard('#d9f2e8', { emissive: color, emissiveIntensity: 0.8 });
    [-1, 1].forEach((side) => addSphere(root, 0.035, [side * 0.105, 2.1, 0.34], eyeMaterial, 0));
    const cape = addBox(root, [classId === 'guardian' ? 0.92 : 0.72, 1.12, 0.055], [0, 1.26, -0.43], dark, [0.12, 0, 0]);
    addSphere(root, 0.09, [-0.3, 1.78, -0.38], main, 0);
    addSphere(root, 0.09, [0.3, 1.78, -0.38], main, 0);
    if (classId === 'ranger') {
      for (let i = 0; i < 3; i += 1) {
        addCylinder(root, 0.018, 0.018, 1.05, 5, [-0.36 + i * 0.09, 1.48, -0.54], standard('#c8d6cb'), [0.18, 0, -0.18]);
      }
    }

    const leftArm = new THREE.Group();
    const rightArm = new THREE.Group();
    leftArm.position.set(-0.55, 1.65, 0);
    rightArm.position.set(0.55, 1.65, 0);
    root.add(leftArm, rightArm);
    addCapsule(leftArm, 0.14, 0.56, [0, -0.4, 0], classId === 'guardian' ? main : dark);
    addSphere(leftArm, 0.16, [0, -0.84, 0], skin, 0);
    addCapsule(rightArm, 0.14, 0.56, [0, -0.4, 0], classId === 'guardian' ? main : dark);
    addSphere(rightArm, 0.16, [0, -0.84, 0], skin, 0);

    let weapon;
    if (classId === 'guardian') {
      weapon = new THREE.Group();
      weapon.position.set(0, -0.75, 0.15);
      rightArm.add(weapon);
      addBox(weapon, [0.11, 1.5, 0.12], [0, -0.5, 0], standard('#c6d0ca', { metalness: 0.75 }));
      addBox(weapon, [0.65, 0.1, 0.15], [0, 0.17, 0], main);
      const shield = addCylinder(leftArm, 0.61, 0.61, 0.13, 10, [0, -0.42, 0.32], main, [Math.PI / 2, 0, 0]);
      addSphere(shield, 0.18, [0, 0.1, 0], glow);
    } else if (classId === 'ranger') {
      weapon = new THREE.Group();
      weapon.position.set(0, -0.55, 0.28);
      rightArm.add(weapon);
      addMesh(weapon, new THREE.TorusGeometry(0.58, 0.035, 5, 20, Math.PI * 1.45), main, [0, 0, 0], [0, 0, -Math.PI * 0.72]);
      addBox(weapon, [0.035, 1.25, 0.035], [0.05, 0, 0.25], standard('#d5e4d8'));
    } else {
      weapon = new THREE.Group();
      weapon.position.set(0, -0.45, 0.15);
      rightArm.add(weapon);
      addCylinder(weapon, 0.045, 0.055, 2.3, 7, [0, -0.3, 0], leather);
      addSphere(weapon, 0.25, [0, 0.95, 0], glow, 1);
      const orbit = addMesh(weapon, new THREE.TorusGeometry(0.38, 0.025, 5, 20), glow, [0, 0.95, 0], [Math.PI / 2, 0, 0]);
      orbit.castShadow = false;
    }
    return { root, leftLeg, rightLeg, leftArm, rightArm, weapon, cape, classId };
  }

  createLabel(name, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 80;
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false, depthWrite: false });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(2.45, 0.77, 1);
    sprite.renderOrder = 20;
    return { canvas, texture, sprite, name, color };
  }

  updateLabel(record, player) {
    const key = `${player.hp}-${player.downed}-${player.dead}-${Math.ceil(player.bleedout)}`;
    if (record.labelKey === key) return;
    record.labelKey = key;
    const { canvas, texture, name, color } = record.label;
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.textAlign = 'center';
    context.font = '600 22px Segoe UI, Arial, sans-serif';
    context.shadowColor = '#000';
    context.shadowBlur = 6;
    context.fillStyle = player.downed ? '#ff8a75' : '#f0eee5';
    context.fillText(name.slice(0, 16), 128, 28);
    context.shadowBlur = 0;
    context.fillStyle = 'rgba(0,0,0,.65)';
    context.fillRect(54, 43, 148, 8);
    context.fillStyle = player.downed ? '#e95f4e' : color;
    context.fillRect(54, 43, 148 * clamp(player.hp / player.maxHp, 0, 1), 8);
    if (player.downed || player.dead) {
      context.font = '700 15px Segoe UI, Arial, sans-serif';
      context.fillStyle = player.dead ? '#9a9a9a' : '#ff9b87';
      context.fillText(player.dead ? 'ПОГИБ' : `ПАЛ · ${Math.ceil(player.bleedout)}`, 128, 72);
    }
    texture.needsUpdate = true;
  }

  syncPlayers(game, dt, clientId) {
    const seen = new Set();
    for (const player of game.players) {
      seen.add(player.id);
      const record = this.players.get(player.id) || this.createPlayerRecord(player);
      const target = to3(player.x, player.y);
      const blend = 1 - Math.exp(-dt * 18);
      record.group.position.lerp(target, blend);
      record.group.rotation.y = lerpAngle(record.group.rotation.y, Math.PI / 2 - player.angle, blend);
      const speed = Math.hypot(player.vx || 0, player.vy || 0);
      record.walk += dt * speed * 0.045;
      const moving = clamp(speed / 230, 0, 1.35);
      const swing = Math.sin(record.walk) * 0.65 * moving;
      record.model.leftLeg.rotation.x = swing;
      record.model.rightLeg.rotation.x = -swing;
      record.model.leftArm.rotation.x = -swing * 0.65;
      record.model.rightArm.rotation.x = swing * 0.65;
      if (player.attackCooldown > 0.04 && !player.downed) {
        record.model.rightArm.rotation.x -= clamp(player.attackCooldown * 3.5, 0, 1.15);
      }
      record.model.root.position.y = player.downed || player.dead ? 0.32 : Math.abs(Math.sin(record.walk * 2)) * 0.035 * moving;
      record.model.root.rotation.z = lerp(record.model.root.rotation.z, player.downed || player.dead ? 1.42 : 0, 1 - Math.exp(-dt * 8));
      record.model.root.rotation.x = lerp(record.model.root.rotation.x, player.downed || player.dead ? 0 : moving * 0.11, 1 - Math.exp(-dt * 7));
      record.model.rightArm.rotation.z = lerp(record.model.rightArm.rotation.z, player.attackCooldown > 0.04 && player.classId === 'guardian' ? -0.45 : 0, 1 - Math.exp(-dt * 12));
      record.model.cape.rotation.x = 0.12 + moving * 0.28 + Math.sin(game.time * 5 + record.walk) * 0.045;
      record.shield.visible = player.shieldTime > 0 && !player.downed && !player.dead;
      record.shield.rotation.y += dt * 0.8;
      record.localRing.visible = player.id === clientId && !player.dead;
      record.localRing.material.opacity = 0.35 + Math.sin(game.time * 4) * 0.15;
      record.reviveRing.visible = player.downed && player.reviveProgress > 0;
      if (record.reviveRing.visible) {
        const progress = clamp(player.reviveProgress / 2.2, 0.05, 1);
        record.reviveRing.scale.setScalar(progress);
        record.reviveRing.material.opacity = 0.5 + progress * 0.5;
      }
      record.label.sprite.visible = player.id !== clientId && (!player.dead || game.time % 2 < 1.5);
      this.updateLabel(record, player);
    }
    for (const [id, record] of this.players) {
      if (!seen.has(id)) {
        this.dynamic.remove(record.group);
        disposeObject(record.group);
        this.players.delete(id);
      }
    }
  }

  createBossRecord(game) {
    const group = new THREE.Group();
    const model = this.createBossModel(game.bossId);
    group.add(model.root);
    const aura = floorRing(game.boss.radius * SCALE * 0.85, game.boss.radius * SCALE, STYLES[game.bossId].color, 0.25, 64);
    aura.position.y = 0.04;
    group.add(aura);
    const phaseLight = new THREE.PointLight(STYLES[game.bossId].color, 22, 15, 2);
    phaseLight.position.set(0, 3, 0);
    group.add(phaseLight);
    group.position.copy(to3(game.boss.x, game.boss.y));
    this.dynamic.add(group);
    this.bossRecord = { group, model, aura, phaseLight };
    return this.bossRecord;
  }

  createBossModel(bossId) {
    if (bossId === 'anubis') return this.createAnubis();
    if (bossId === 'fenrir') return this.createFenrir();
    return this.createMinotaur();
  }

  createMinotaur() {
    const root = new THREE.Group();
    const fur = standard('#332a26');
    const armor = standard('#714b36', { metalness: 0.38 });
    const bronze = standard('#9b6a3e', { metalness: 0.55 });
    const horn = standard('#c7b997');
    const glow = standard('#ff7145', { emissive: '#ff431f', emissiveIntensity: 2 });
    const legs = [];
    [-0.72, 0.72].forEach((x) => {
      const leg = new THREE.Group();
      leg.position.set(x, 2.05, 0);
      addCapsule(leg, 0.43, 1.3, [0, -1.02, 0], fur);
      addBox(leg, [0.9, 0.55, 1.35], [0, -2.0, 0.22], armor);
      root.add(leg); legs.push(leg);
    });
    addBox(root, [2.75, 2.15, 1.55], [0, 3.15, 0], fur);
    addBox(root, [2.9, 0.55, 1.75], [0, 3.75, 0], armor);
    addBox(root, [1.8, 0.7, 1.7], [0, 2.35, 0], bronze);
    const chestRune = addMesh(root, new THREE.TorusGeometry(0.48, 0.08, 6, 12), glow, [0, 3.15, 0.83]);
    chestRune.castShadow = false;
    const arms = [];
    [-1, 1].forEach((side) => {
      const arm = new THREE.Group();
      arm.position.set(side * 1.7, 3.75, 0);
      addSphere(arm, 0.68, [0, 0, 0], armor);
      addCapsule(arm, 0.39, 1.35, [0, -1.15, 0], fur);
      addBox(arm, [0.85, 0.75, 0.9], [0, -1.15, 0], armor);
      root.add(arm); arms.push(arm);
    });
    addBox(root, [1.45, 1.15, 1.15], [0, 4.85, 0.2], fur);
    addBox(root, [0.95, 0.65, 0.9], [0, 4.52, 0.95], fur);
    addBox(root, [0.62, 0.23, 0.15], [0, 4.45, 1.43], standard('#171716'));
    [-1, 1].forEach((side) => {
      addMesh(root, new THREE.ConeGeometry(0.25, 0.75, 5), fur, [side * 0.92, 4.85, 0.15], [0, 0, side * -1.35]);
    });
    addMesh(root, new THREE.TorusGeometry(0.25, 0.055, 6, 16), bronze, [0, 4.36, 1.48]);
    [-1, 1].forEach((side) => {
      addMesh(root, new THREE.ConeGeometry(0.27, 1.8, 7), horn, [side * 1.02, 5.55, 0.1], [0, 0, side * -0.8]);
      addSphere(root, 0.095, [side * 0.35, 4.92, 0.79], glow, 0);
    });
    const axe = new THREE.Group();
    axe.position.set(0, -1.7, 0.25);
    arms[1].add(axe);
    addCylinder(axe, 0.1, 0.12, 3.8, 8, [0, -0.5, 0], standard('#4a3325'));
    const axeMetal = standard('#a4aaa5', { metalness: 0.75 });
    addBox(axe, [0.65, 0.75, 0.22], [0, -2.15, 0], axeMetal);
    [-1, 1].forEach((side) => {
      addMesh(axe, new THREE.ConeGeometry(0.62, 1.25, 4), axeMetal, [side * 0.95, -2.15, 0], [0, 0, side * -Math.PI / 2]);
    });
    addBox(axe, [1.25, 0.14, 0.24], [0, -2.15, 0.03], glow);
    return { root, legs, arms, head: null, axe, kind: 'minotaur' };
  }

  createAnubis() {
    const root = new THREE.Group();
    const black = standard('#171f22', { metalness: 0.35 });
    const gold = standard('#b7944f', { metalness: 0.65 });
    const turquoise = standard('#4ed7c5', { emissive: '#28c7b8', emissiveIntensity: 2 });
    const legs = [];
    [-0.48, 0.48].forEach((x) => {
      const leg = new THREE.Group();
      leg.position.set(x, 2.2, 0);
      addCapsule(leg, 0.3, 1.65, [0, -1.15, 0], black);
      addBox(leg, [0.62, 0.8, 0.75], [0, -0.7, 0], gold);
      root.add(leg); legs.push(leg);
    });
    addCylinder(root, 0.85, 1.25, 2.5, 6, [0, 2.25, 0], black);
    addBox(root, [1.85, 1.8, 1.05], [0, 4.0, 0], black);
    addBox(root, [2.35, 0.35, 1.35], [0, 4.65, 0], gold);
    addMesh(root, new THREE.TorusGeometry(0.48, 0.09, 6, 16), turquoise, [0, 4.05, 0.58]);
    const arms = [];
    [-1, 1].forEach((side) => {
      const arm = new THREE.Group();
      arm.position.set(side * 1.2, 4.45, 0);
      addCapsule(arm, 0.27, 1.4, [0, -1.05, 0], black);
      addBox(arm, [0.65, 0.7, 0.7], [0, -0.45, 0], gold);
      root.add(arm); arms.push(arm);
    });
    addBox(root, [0.95, 1.15, 0.85], [0, 5.45, 0.1], black);
    addBox(root, [0.58, 0.52, 1.15], [0, 5.25, 0.85], black);
    [-1, 1].forEach((side) => {
      addMesh(root, new THREE.ConeGeometry(0.26, 1.55, 5), black, [side * 0.36, 6.55, 0], [0, 0, side * -0.13]);
      addSphere(root, 0.08, [side * 0.25, 5.6, 0.58], turquoise, 0);
    });
    addBox(root, [1.5, 0.18, 1.0], [0, 4.95, 0], gold);
    [-1, 1].forEach((side) => {
      addBox(root, [0.36, 1.75, 0.18], [side * 0.66, 5.25, -0.15], gold, [0, 0, side * -0.12]);
      for (let stripe = 0; stripe < 4; stripe += 1) {
        addBox(root, [0.38, 0.09, 0.2], [side * 0.66, 4.75 + stripe * 0.34, -0.03], turquoise);
      }
    });
    addMesh(root, new THREE.TorusGeometry(0.75, 0.11, 6, 20, Math.PI), gold, [0, 4.55, 0.62], [0, 0, Math.PI]);
    const staff = new THREE.Group();
    staff.position.set(0, -1.3, 0.25);
    arms[1].add(staff);
    addCylinder(staff, 0.07, 0.09, 5.8, 8, [0, 0.2, 0], gold);
    addMesh(staff, new THREE.TorusGeometry(0.55, 0.09, 7, 20), turquoise, [0, 3.25, 0]);
    addBox(staff, [0.12, 1.25, 0.12], [0, 2.75, 0], turquoise);
    addBox(staff, [0.85, 0.12, 0.12], [0, 2.55, 0], turquoise);
    return { root, legs, arms, staff, kind: 'anubis' };
  }

  createFenrir() {
    const root = new THREE.Group();
    const fur = standard('#26353d');
    const dark = standard('#152229');
    const ice = standard('#769eb0', { metalness: 0.25, roughness: 0.45 });
    const glow = standard('#74e5f2', { emissive: '#41d9ee', emissiveIntensity: 2.2 });
    addCapsule(root, 1.0, 2.0, [0, 2.15, 0], fur, [Math.PI / 2, 0, 0]);
    addSphere(root, 1.12, [0, 2.3, 1.15], fur, 1);
    const haunch = addSphere(root, 0.98, [0, 2.15, -1.35], fur, 1);
    haunch.scale.set(0.92, 1, 1.1);
    const legs = [];
    [-0.72, 0.72].forEach((x) => {
      [-1.25, 1.25].forEach((z) => {
        const leg = new THREE.Group();
        leg.position.set(x, 1.75, z);
        addCapsule(leg, 0.28, 1.15, [0, -0.85, 0], fur);
        addBox(leg, [0.62, 0.35, 0.95], [0, -1.7, 0.18], dark);
        addBox(leg, [0.58, 0.75, 0.68], [0, -0.45, 0], ice);
        root.add(leg); legs.push(leg);
      });
    });
    const head = new THREE.Group();
    head.position.set(0, 3.05, 2.15);
    const skull = addSphere(head, 0.86, [0, 0, 0], fur, 1);
    skull.scale.set(1, 0.86, 1.08);
    addCapsule(head, 0.4, 0.55, [0, -0.25, 0.92], dark, [Math.PI / 2, 0, 0]);
    addSphere(head, 0.25, [0, -0.12, 1.47], standard('#0c1216'), 0);
    [-1, 1].forEach((side) => {
      addMesh(head, new THREE.ConeGeometry(0.075, 0.38, 5), standard('#d9e2dc'), [side * 0.24, -0.54, 1.15], [0, 0, Math.PI]);
    });
    [-1, 1].forEach((side) => {
      addMesh(head, new THREE.ConeGeometry(0.35, 1.25, 5), fur, [side * 0.48, 1.0, -0.15], [0, 0, side * -0.15]);
      addSphere(head, 0.11, [side * 0.36, 0.22, 0.7], glow, 0);
    });
    root.add(head);
    for (let i = 0; i < 6; i += 1) {
      addMesh(root, new THREE.ConeGeometry(0.22, 1.05, 5), ice, [0, 3.25, -1.4 + i * 0.55], [0.25, 0, 0]);
    }
    const tail = new THREE.Group();
    tail.position.set(0, 2.45, -2.0);
    addCapsule(tail, 0.36, 1.0, [0, 0, -0.55], fur, [Math.PI / 2, 0, 0]);
    addCapsule(tail, 0.28, 0.85, [0, 0.28, -1.45], fur, [Math.PI / 2.6, 0, 0]);
    addSphere(tail, 0.34, [0, 0.58, -2.05], fur, 1);
    root.add(tail);
    return { root, legs, head, tail, kind: 'fenrir' };
  }

  syncBoss(game, dt) {
    const record = this.bossRecord || this.createBossRecord(game);
    const boss = game.boss;
    const blend = 1 - Math.exp(-dt * 12);
    record.group.position.lerp(to3(boss.x, boss.y), blend);
    record.group.rotation.y = lerpAngle(record.group.rotation.y, Math.PI / 2 - boss.angle, blend);
    const casting = game.telegraphs.some((telegraph) => !telegraph.resolved);
    const walk = Math.sin(game.time * 5) * 0.22;
    record.model.legs?.forEach((leg, index) => { leg.rotation.x = walk * (index % 2 ? -1 : 1); });
    if (record.model.arms) {
      record.model.arms.forEach((arm, index) => {
        arm.rotation.x = lerp(arm.rotation.x, casting ? -0.75 - index * 0.25 : -walk * 0.5, 1 - Math.exp(-dt * 7));
      });
    }
    if (record.model.kind === 'fenrir') {
      record.model.head.rotation.x = Math.sin(game.time * 2.2) * 0.08 + (casting ? -0.18 : 0);
      record.model.tail.rotation.y = Math.sin(game.time * 3.5) * 0.45;
    }
    record.model.root.position.y = Math.sin(game.time * 2) * 0.045;
    const bossTilt = boss.hp <= 0 ? 1.35 : boss.stunTime > 0 ? 0.17 : 0;
    record.model.root.rotation.z = lerp(record.model.root.rotation.z, bossTilt, 1 - Math.exp(-dt * 4));
    record.aura.material.color.set(boss.stunTime > 0 ? '#f5d374' : STYLES[game.bossId].color);
    record.aura.material.opacity = (boss.stunTime > 0 ? 0.42 : 0.12 + boss.phase * 0.07) + Math.sin(game.time * 3) * 0.035;
    record.aura.rotation.z += dt * (0.1 + boss.phase * 0.05);
    record.phaseLight.intensity = 14 + boss.phase * 8 + Math.sin(game.time * 4) * 3;
  }

  syncProjectiles(game, dt) {
    const seen = new Set();
    for (const projectile of game.projectiles) {
      seen.add(projectile.id);
      let mesh = this.projectiles.get(projectile.id);
      const color = projectile.friendly ? CLASS_COLORS[projectile.classId] : projectile.color || STYLES[game.bossId].color;
      if (!mesh) {
        const radius = Math.max(0.12, projectile.radius * SCALE * 1.4) * (projectile.ultimate ? 1.45 : 1);
        mesh = new THREE.Group();
        const core = addSphere(mesh, radius, [0, 0, 0], basic(color, { opacity: 1, blending: THREE.AdditiveBlending }), 1);
        core.castShadow = false;
        const halo = addSphere(mesh, radius * 2.2, [0, 0, 0], basic(color, { opacity: 0.16, blending: THREE.AdditiveBlending }), 1);
        halo.castShadow = false;
        this.dynamic.add(mesh);
        this.projectiles.set(projectile.id, mesh);
      }
      const target = to3(projectile.x, projectile.y, projectile.friendly ? 1.25 : 1.05);
      mesh.position.lerp(target, 1 - Math.exp(-dt * 35));
      mesh.rotation.y = Math.atan2(projectile.vx, projectile.vy);
    }
    for (const [id, mesh] of this.projectiles) {
      if (!seen.has(id)) {
        this.dynamic.remove(mesh);
        disposeObject(mesh);
        this.projectiles.delete(id);
      }
    }
  }

  createTelegraph(telegraph) {
    const group = new THREE.Group();
    const material = basic('#ef4938', { opacity: 0.13 });
    const outlineMaterial = basic('#ff8061', { opacity: 0.8 });
    let fill;
    let progress;
    if (telegraph.kind === 'circle') {
      const radius = telegraph.radius * SCALE;
      fill = new THREE.Mesh(new THREE.CircleGeometry(radius, 56), material);
      fill.rotation.x = -Math.PI / 2;
      group.add(fill);
      const outline = floorRing(radius - 0.07, radius + 0.07, '#ff8061', 0.85);
      outline.material = outlineMaterial;
      group.add(outline);
      progress = new THREE.Mesh(new THREE.CircleGeometry(radius * 0.88, 48), basic('#ff9a62', { opacity: 0.1 }));
      progress.rotation.x = -Math.PI / 2;
      progress.position.y = 0.015;
      group.add(progress);
      group.position.copy(to3(telegraph.x, telegraph.y, 0.045));
    } else if (telegraph.kind === 'ring') {
      const inner = telegraph.inner * SCALE;
      const outer = telegraph.outer * SCALE;
      fill = floorRing(inner, outer, '#ef4938', 0.14);
      fill.material = material;
      group.add(fill);
      const innerLine = floorRing(inner - 0.07, inner + 0.07, '#ff8061', 0.8);
      const outerLine = floorRing(outer - 0.07, outer + 0.07, '#ff8061', 0.8);
      innerLine.material = outlineMaterial;
      outerLine.material = outlineMaterial.clone();
      group.add(innerLine, outerLine);
      progress = floorRing(inner, outer, '#ff9a62', 0.08);
      group.add(progress);
      group.position.copy(to3(telegraph.x, telegraph.y, 0.045));
    } else {
      const length = telegraph.length * SCALE;
      const width = telegraph.width * SCALE;
      fill = new THREE.Mesh(new THREE.PlaneGeometry(length, width), material);
      fill.rotation.x = -Math.PI / 2;
      group.add(fill);
      const outline = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(length, width)), new THREE.LineBasicMaterial({ color: '#ff8061', transparent: true, opacity: 0.9 }));
      outline.rotation.x = -Math.PI / 2;
      outline.position.y = 0.02;
      group.add(outline);
      progress = new THREE.Mesh(new THREE.PlaneGeometry(length, 0.14), basic('#ffb078', { opacity: 0.75 }));
      progress.rotation.x = -Math.PI / 2;
      progress.position.y = 0.025;
      group.add(progress);
      const start = to3(telegraph.x, telegraph.y, 0.05);
      group.position.set(start.x + Math.cos(telegraph.angle) * length / 2, start.y, start.z + Math.sin(telegraph.angle) * length / 2);
      group.rotation.y = -telegraph.angle;
    }
    group.traverse((child) => { child.castShadow = false; child.receiveShadow = false; child.renderOrder = 3; });
    this.dynamic.add(group);
    const record = { group, fill, progress, material, kind: telegraph.kind };
    this.telegraphs.set(telegraph.id, record);
    return record;
  }

  syncTelegraphs(game) {
    const seen = new Set();
    for (const telegraph of game.telegraphs) {
      seen.add(telegraph.id);
      const record = this.telegraphs.get(telegraph.id) || this.createTelegraph(telegraph);
      const progress = clamp(telegraph.elapsed / telegraph.delay, 0, 1);
      const fade = telegraph.resolved ? clamp((telegraph.delay + 0.32 - telegraph.elapsed) / 0.32, 0, 1) : 1;
      record.group.visible = fade > 0;
      record.material.color.set(telegraph.resolved ? '#ffd2a4' : '#ef4938');
      record.material.opacity = telegraph.resolved ? 0.4 * fade : 0.08 + progress * 0.18;
      if (record.kind === 'line') {
        record.progress.scale.x = Math.max(0.001, progress);
        record.progress.material.opacity = 0.25 + progress * 0.65;
      } else {
        record.progress.scale.setScalar(Math.max(0.001, progress));
        record.progress.material.opacity = 0.04 + progress * 0.13;
      }
    }
    for (const [id, record] of this.telegraphs) {
      if (!seen.has(id)) {
        this.dynamic.remove(record.group);
        disposeObject(record.group);
        this.telegraphs.delete(id);
      }
    }
  }

  handleEvent(event, game) {
    const color = STYLES[game.bossId].color;
    if (event.kind === 'bossHit') {
      this.hitPulse = 1;
      this.spawnSparks(event.x, event.y, color, 5, 1.5);
      this.spawnFloater(event.x, event.y, `−${event.amount}`, '#ffd2a7');
    } else if (event.kind === 'playerHit') {
      this.spawnSparks(event.x, event.y, '#ff6651', 8, 2.2);
      this.spawnFloater(event.x, event.y, `−${event.amount}`, '#ff7764');
    } else if (event.kind === 'heal') {
      this.spawnSparks(event.x, event.y, '#75e0aa', 9, 1.4);
      this.spawnFloater(event.x, event.y, `+${event.amount}`, '#7ce2ae');
    } else if (event.kind === 'impact') {
      this.spawnRing(event.x, event.y, color, Math.min(16, (event.radius || 150) * SCALE));
      this.spawnSparks(event.x, event.y, color, 12, 3.2);
      this.shake = Math.max(this.shake, 0.22);
    } else if (event.kind === 'stagger') {
      this.spawnRing(event.x, event.y, '#f5d374', 19);
      this.spawnSparks(event.x, event.y, '#f5d374', 22, 4.2);
      this.shake = Math.max(this.shake, 0.45);
    } else if (event.kind === 'ultimate') {
      this.spawnRing(event.x, event.y, CLASS_COLORS[event.classId] || color, 17);
      this.spawnSparks(event.x, event.y, CLASS_COLORS[event.classId] || color, 20, 3.8);
      this.shake = Math.max(this.shake, 0.28);
    } else if (event.kind === 'phase') {
      this.spawnRing(event.x, event.y, color, 18);
      this.shake = Math.max(this.shake, 0.5);
    } else if (event.kind === 'shield') {
      this.spawnRing(event.x, event.y, '#f4cf78', 14);
    } else if (event.kind === 'healPulse' || event.kind === 'revive') {
      this.spawnRing(event.x, event.y, '#78d6a9', 12);
    } else if (event.kind === 'dash') {
      this.spawnSparks(event.x, event.y, '#d8e0d7', 5, 1.2);
    }
  }

  spawnSparks(x, y, color, count, speed) {
    const origin = to3(x, y, 1.1);
    for (let i = 0; i < count; i += 1) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.07), basic(color, { opacity: 1, blending: THREE.AdditiveBlending }));
      mesh.position.copy(origin);
      mesh.castShadow = false;
      this.effectLayer.add(mesh);
      const angle = Math.random() * TAU;
      const velocity = speed * (0.5 + Math.random());
      this.effects.push({ type: 'spark', mesh, life: 0.45 + Math.random() * 0.35, maxLife: 0.8, vx: Math.cos(angle) * velocity, vy: 1 + Math.random() * 2.5, vz: Math.sin(angle) * velocity });
    }
  }

  spawnRing(x, y, color, maxRadius) {
    const mesh = floorRing(0.85, 1, color, 0.8, 48);
    mesh.position.copy(to3(x, y, 0.12));
    mesh.scale.setScalar(0.3);
    this.effectLayer.add(mesh);
    this.effects.push({ type: 'ring', mesh, life: 0.6, maxLife: 0.6, maxRadius: Math.max(1, maxRadius) });
  }

  spawnFloater(x, y, text, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 80;
    const context = canvas.getContext('2d');
    context.textAlign = 'center';
    context.font = '700 35px Arial, sans-serif';
    context.shadowColor = '#000';
    context.shadowBlur = 7;
    context.fillStyle = color;
    context.fillText(text, 128, 52);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false, depthWrite: false });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(2.1, 0.66, 1);
    sprite.position.copy(to3(x, y, 2.7));
    sprite.renderOrder = 30;
    this.effectLayer.add(sprite);
    this.effects.push({ type: 'floater', mesh: sprite, life: 0.9, maxLife: 0.9 });
  }

  updateEffects(dt) {
    const alive = [];
    for (const effect of this.effects) {
      effect.life -= dt;
      if (effect.life <= 0) {
        this.effectLayer.remove(effect.mesh);
        disposeObject(effect.mesh);
        continue;
      }
      const ratio = clamp(effect.life / effect.maxLife, 0, 1);
      if (effect.type === 'spark') {
        effect.vy -= 7 * dt;
        effect.mesh.position.x += effect.vx * dt;
        effect.mesh.position.y = Math.max(0.08, effect.mesh.position.y + effect.vy * dt);
        effect.mesh.position.z += effect.vz * dt;
        effect.mesh.rotation.x += dt * 8;
        effect.mesh.material.opacity = ratio;
      } else if (effect.type === 'ring') {
        const progress = 1 - ratio;
        effect.mesh.scale.setScalar(0.3 + effect.maxRadius * progress);
        effect.mesh.material.opacity = ratio * 0.7;
      } else {
        effect.mesh.position.y += dt * 1.25;
        effect.mesh.material.opacity = ratio;
      }
      alive.push(effect);
    }
    this.effects = alive;
  }

  updateWeather(dt) {
    if (!this.weather) return;
    const { positions, count, bossId, points } = this.weather;
    for (let i = 0; i < count; i += 1) {
      const index = i * 3;
      if (bossId === 'fenrir') {
        positions[index + 1] -= dt * (1.2 + (i % 7) * 0.12);
        positions[index] += dt * 0.35;
        if (positions[index + 1] < 0) positions[index + 1] = 18;
      } else if (bossId === 'anubis') {
        positions[index] += dt * (2.4 + (i % 5) * 0.3);
        positions[index + 1] += Math.sin(i + performance.now() * 0.001) * dt * 0.2;
        if (positions[index] > 50) positions[index] = -50;
      } else {
        positions[index + 1] += dt * (0.35 + (i % 5) * 0.08);
        if (positions[index + 1] > 10) positions[index + 1] = 0;
      }
    }
    points.geometry.attributes.position.needsUpdate = true;
  }

  updateCamera(game, dt, clientId) {
    const me = game.players.find((player) => player.id === clientId) || game.players[0];
    if (!me) return;
    const playerPosition = to3(me.x, me.y, 1.4);
    const bossPosition = to3(game.boss.x, game.boss.y, 2.2);
    const bossOffset = playerPosition.clone().sub(bossPosition);
    bossOffset.y = 0;
    if (this.lockOn && bossOffset.length() > 4.5) {
      const desiredAway = bossOffset.normalize();
      this.cameraAway.lerp(desiredAway, 1 - Math.exp(-dt * 2.2)).normalize();
    }
    const away = this.cameraAway.clone().normalize().applyAxisAngle(UP, this.orbitYaw);

    let desired;
    let look;
    if (game.time < 2.6) {
      desired = bossPosition.clone().addScaledVector(away, 11.5).add(new THREE.Vector3(0, 6.2, 0));
      look = bossPosition.clone();
    } else {
      desired = playerPosition.clone().addScaledVector(away, this.zoom).add(new THREE.Vector3(0, 4.8 + this.zoom * 0.2 + this.orbitPitch * 8, 0));
      look = playerPosition.clone().multiplyScalar(0.56).add(bossPosition.clone().multiplyScalar(0.44));
      look.y = 2.05;
    }
    desired.x = clamp(desired.x, -48, 48);
    desired.z = clamp(desired.z, -34, 34);

    const fromBoss = desired.clone().sub(bossPosition);
    fromBoss.y = 0;
    const bossCameraDistance = fromBoss.length();
    const safeDistance = game.boss.radius * SCALE + 5.5;
    if (bossCameraDistance < safeDistance) {
      if (fromBoss.lengthSq() < 0.01) fromBoss.copy(away);
      fromBoss.normalize();
      desired.x = bossPosition.x + fromBoss.x * safeDistance;
      desired.z = bossPosition.z + fromBoss.z * safeDistance;
      desired.y = Math.max(desired.y, 8.6);
    }

    if (!this.cameraInitialized) {
      this.cameraBase.copy(desired);
      this.cameraLook.copy(look);
      this.cameraInitialized = true;
    } else {
      this.cameraBase.lerp(desired, 1 - Math.exp(-dt * 4.5));
      this.cameraLook.lerp(look, 1 - Math.exp(-dt * 6));
    }
    const actualFromBoss = this.cameraBase.clone().sub(bossPosition);
    actualFromBoss.y = 0;
    if (actualFromBoss.length() < safeDistance) {
      if (actualFromBoss.lengthSq() < 0.01) actualFromBoss.copy(away);
      actualFromBoss.normalize();
      this.cameraBase.x = bossPosition.x + actualFromBoss.x * safeDistance;
      this.cameraBase.z = bossPosition.z + actualFromBoss.z * safeDistance;
      this.cameraBase.y = Math.max(this.cameraBase.y, 8.6);
    }
    this.camera.position.copy(this.cameraBase);
    if (this.shake > 0.002) {
      this.camera.position.x += (Math.random() - 0.5) * this.shake;
      this.camera.position.y += (Math.random() - 0.5) * this.shake * 0.6;
      this.camera.position.z += (Math.random() - 0.5) * this.shake;
      this.shake *= Math.pow(0.025, dt);
    }
    this.camera.lookAt(this.cameraLook);
    const targetFov = me.sprinting ? 64 : 61;
    if (Math.abs(this.camera.fov - targetFov) > 0.02) {
      this.camera.fov = lerp(this.camera.fov, targetFov, 1 - Math.exp(-dt * 5));
      this.camera.updateProjectionMatrix();
    }
  }

  orbit(dx, dy) {
    this.lockOn = false;
    this.orbitYaw -= dx * 0.005;
    this.orbitPitch = clamp(this.orbitPitch + dy * 0.003, -0.28, 0.38);
  }

  zoomCamera(delta) {
    this.zoom = clamp(this.zoom + delta * 0.008, 8, 16);
  }

  toggleLock() {
    this.lockOn = !this.lockOn;
    if (this.lockOn) {
      this.orbitYaw = 0;
      this.orbitPitch = 0;
    }
    return this.lockOn;
  }

  screenToWorld(x, y, game) {
    this.pointer.set((x / window.innerWidth) * 2 - 1, -(y / window.innerHeight) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const point = new THREE.Vector3();
    if (!this.raycaster.ray.intersectPlane(this.groundPlane, point)) {
      return game ? { x: game.boss.x, y: game.boss.y } : { x: 800, y: 450 };
    }
    return {
      x: clamp(point.x / SCALE + 800, 0, 1600),
      y: clamp(point.z / SCALE + 450, 0, 900)
    };
  }

  getMoveVector(input) {
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    forward.y = 0;
    if (forward.lengthSq() < 0.001) forward.set(0, 0, -1);
    forward.normalize();
    const right = new THREE.Vector3().crossVectors(forward, UP).normalize();
    const move = new THREE.Vector3();
    move.addScaledVector(forward, Number(Boolean(input.up)) - Number(Boolean(input.down)));
    move.addScaledVector(right, Number(Boolean(input.right)) - Number(Boolean(input.left)));
    if (move.lengthSq() > 1) move.normalize();
    return { x: move.x, y: move.z };
  }

  render(game, options) {
    const key = `${game.bossId}-${game.decorSeed}`;
    if (key !== this.worldKey) this.resetWorld(game);
    const dt = clamp(options.dt || 0.016, 0.001, 0.05);
    this.syncTelegraphs(game);
    this.syncProjectiles(game, dt);
    this.syncPlayers(game, dt, options.clientId);
    this.syncBoss(game, dt);
    this.updateEffects(dt);
    this.updateWeather(dt);
    this.updateCamera(game, dt, options.clientId);

    if (options.aim && !options.endShown) {
      this.aimReticle.visible = true;
      this.aimReticle.position.copy(to3(options.aim.x, options.aim.y, 0.08));
      const pulse = 1 + Math.sin(game.time * 6) * 0.12 + this.hitPulse * 0.45;
      this.aimReticle.scale.setScalar(pulse);
      this.hitPulse *= Math.pow(0.02, dt);
    } else this.aimReticle.visible = false;
    this.renderer.render(this.scene, this.camera);
  }
}
