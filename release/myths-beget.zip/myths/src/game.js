const { CLASSES, BOSSES, WORLD } = require('./config');

const TAU = Math.PI * 2;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const randomBetween = (min, max) => min + Math.random() * (max - min);

function angleDifference(a, b) {
  return Math.atan2(Math.sin(a - b), Math.cos(a - b));
}

class Game {
  constructor(room) {
    this.room = room;
    this.bossId = room.bossId;
    this.config = BOSSES[this.bossId];
    this.world = WORLD;
    this.time = 0;
    this.players = room.players;
    this.projectiles = [];
    this.telegraphs = [];
    this.events = [];
    this.ended = false;
    this.result = null;
    this.entityId = 1;
    this.lastAttack = '';
    this.decorSeed = Math.floor(Math.random() * 100000);

    const playerList = [...this.players.values()];
    const maxHp = Math.round(this.config.baseHp * (1 + Math.max(0, playerList.length - 1) * 0.62));
    this.boss = {
      id: 'boss',
      x: WORLD.width / 2,
      y: 285,
      angle: Math.PI / 2,
      hp: maxHp,
      maxHp,
      radius: this.config.radius,
      phase: 1,
      attackCooldown: 2.8,
      basicCooldown: 1.2,
      targetTimer: 0,
      targetId: null,
      castLock: 0,
      stagger: 0,
      stunTime: 0
    };

    playerList.forEach((player, index) => {
      const classConfig = CLASSES[player.classId] || CLASSES.ranger;
      const spread = Math.min(420, 130 * Math.max(1, playerList.length - 1));
      const offset = playerList.length === 1 ? 0 : -spread / 2 + (spread * index) / (playerList.length - 1);
      Object.assign(player, {
        x: WORLD.width / 2 + offset,
        y: 735 + Math.abs(offset) * 0.06,
        vx: 0,
        vy: 0,
        angle: -Math.PI / 2,
        hp: classConfig.maxHp,
        maxHp: classConfig.maxHp,
        radius: classConfig.radius,
        attackCooldown: 0,
        abilityCooldown: 0,
        dashCooldown: 0,
        dashTime: 0,
        shieldTime: 0,
        stamina: 100,
        maxStamina: 100,
        sprintDelay: 0,
        sprinting: false,
        ultimate: 0,
        downed: false,
        dead: false,
        bleedout: 0,
        reviveProgress: 0,
        damageDone: 0,
        revives: 0,
        downs: 0,
        prevAbility: false,
        prevDash: false,
        prevUltimate: false,
        input: { up: false, down: false, left: false, right: false, attack: false, ability: false, dash: false, sprint: false, ultimate: false, interact: false, moveX: 0, moveY: 0, aimX: WORLD.width / 2, aimY: 0 }
      });
    });

    this.events.push({ kind: 'intro', bossId: this.bossId });
  }

  update(dt) {
    if (this.ended) return;
    dt = Math.min(dt, 0.06);
    this.time += dt;

    for (const player of this.players.values()) {
      this.updatePlayer(player, dt);
    }

    this.updateProjectiles(dt);
    if (this.boss.hp <= 0) {
      this.finish('victory');
      return;
    }

    this.updateTelegraphs(dt);
    this.updateBoss(dt);
    this.resolveCollisions();
    this.updateRevives(dt);

    if (this.boss.hp <= 0) {
      this.finish('victory');
      return;
    }

    const players = [...this.players.values()];
    if (!players.length || players.every((player) => player.dead || player.downed)) {
      this.finish('defeat');
    }
  }

  updatePlayer(player, dt) {
    const input = player.input || {};
    const abilityPressed = Boolean(input.ability) && !player.prevAbility;
    const dashPressed = Boolean(input.dash) && !player.prevDash;
    const ultimatePressed = Boolean(input.ultimate) && !player.prevUltimate;
    player.prevAbility = Boolean(input.ability);
    player.prevDash = Boolean(input.dash);
    player.prevUltimate = Boolean(input.ultimate);

    player.attackCooldown = Math.max(0, player.attackCooldown - dt);
    player.abilityCooldown = Math.max(0, player.abilityCooldown - dt);
    player.dashCooldown = Math.max(0, player.dashCooldown - dt);
    player.dashTime = Math.max(0, player.dashTime - dt);
    player.shieldTime = Math.max(0, player.shieldTime - dt);
    player.sprintDelay = Math.max(0, player.sprintDelay - dt);

    if (player.dead) {
      player.vx = 0;
      player.vy = 0;
      return;
    }

    const classConfig = CLASSES[player.classId] || CLASSES.ranger;
    let dx = Number(Boolean(input.right)) - Number(Boolean(input.left));
    let dy = Number(Boolean(input.down)) - Number(Boolean(input.up));
    if (Number.isFinite(input.moveX) && Number.isFinite(input.moveY) && Math.hypot(input.moveX, input.moveY) > 0.01) {
      dx = input.moveX;
      dy = input.moveY;
    }
    const magnitude = Math.hypot(dx, dy);
    if (magnitude > 0) {
      dx /= magnitude;
      dy /= magnitude;
    }

    if (player.downed) {
      player.bleedout = Math.max(0, player.bleedout - dt);
      player.sprinting = false;
      const blend = 1 - Math.exp(-dt * 10);
      player.vx += (dx * 62 - player.vx) * blend;
      player.vy += (dy * 62 - player.vy) * blend;
      player.x = clamp(player.x + player.vx * dt, 42 + player.radius, WORLD.width - 42 - player.radius);
      player.y = clamp(player.y + player.vy * dt, 42 + player.radius, WORLD.height - 42 - player.radius);
      if (player.bleedout <= 0) {
        player.dead = true;
        this.events.push({ kind: 'playerLost', playerId: player.id, x: player.x, y: player.y });
      }
      return;
    }

    if (dashPressed && player.dashCooldown <= 0) {
      player.dashCooldown = 2.35;
      player.dashTime = 0.24;
      if (magnitude === 0) {
        dx = Math.cos(player.angle);
        dy = Math.sin(player.angle);
      }
      player.dashX = dx;
      player.dashY = dy;
      this.events.push({ kind: 'dash', playerId: player.id, x: player.x, y: player.y });
    }

    player.sprinting = Boolean(input.sprint) && magnitude > 0 && player.stamina > 0.5 && player.dashTime <= 0;
    if (player.sprinting) {
      player.stamina = Math.max(0, player.stamina - 27 * dt);
      player.sprintDelay = 0.8;
    } else if (player.sprintDelay <= 0) {
      player.stamina = Math.min(player.maxStamina, player.stamina + 20 * dt);
    }

    if (player.dashTime > 0) {
      const dashSpeed = classConfig.speed * 3.35;
      player.vx = (player.dashX || dx) * dashSpeed;
      player.vy = (player.dashY || dy) * dashSpeed;
      player.sprinting = false;
    } else {
      const speed = classConfig.speed * (player.sprinting ? 1.48 : 1);
      const responsiveness = magnitude > 0 ? 14 : 19;
      const blend = 1 - Math.exp(-dt * responsiveness);
      player.vx += (dx * speed - player.vx) * blend;
      player.vy += (dy * speed - player.vy) * blend;
    }

    player.x = clamp(player.x + player.vx * dt, 42 + player.radius, WORLD.width - 42 - player.radius);
    player.y = clamp(player.y + player.vy * dt, 42 + player.radius, WORLD.height - 42 - player.radius);

    if (Number.isFinite(input.aimX) && Number.isFinite(input.aimY)) {
      player.angle = Math.atan2(input.aimY - player.y, input.aimX - player.x);
    }

    if (input.attack && player.attackCooldown <= 0) this.basicAttack(player, classConfig);
    if (abilityPressed && player.abilityCooldown <= 0) this.useAbility(player, classConfig);
    if (ultimatePressed && player.ultimate >= 100) this.useUltimate(player);
  }

  basicAttack(player, classConfig) {
    player.attackCooldown = classConfig.attackRate;
    if (player.classId === 'guardian') {
      const dist = distance(player, this.boss);
      const targetAngle = Math.atan2(this.boss.y - player.y, this.boss.x - player.x);
      const inArc = Math.abs(angleDifference(targetAngle, player.angle)) < 1.12;
      this.events.push({ kind: 'swing', playerId: player.id, x: player.x, y: player.y, angle: player.angle });
      if (dist <= classConfig.attackRange + this.boss.radius && inArc) {
        this.damageBoss(classConfig.damage, player);
      }
      return;
    }

    this.spawnFriendlyProjectile(player, player.angle, classConfig.damage, classConfig.projectileSpeed, {
      radius: player.classId === 'oracle' ? 7 : 4,
      life: 1.8
    });
    this.events.push({ kind: 'shot', playerId: player.id, classId: player.classId, x: player.x, y: player.y });
  }

  useAbility(player, classConfig) {
    player.abilityCooldown = classConfig.abilityCooldown;
    if (player.classId === 'guardian') {
      for (const ally of this.players.values()) {
        if (!ally.dead && !ally.downed && distance(player, ally) <= 285) {
          ally.shieldTime = Math.max(ally.shieldTime, 4);
        }
      }
      this.events.push({ kind: 'shield', playerId: player.id, x: player.x, y: player.y });
      return;
    }

    if (player.classId === 'ranger') {
      for (let i = 0; i < 7; i += 1) {
        const angle = player.angle + (i - 3) * 0.105;
        this.spawnFriendlyProjectile(player, angle, 22, 1050, { radius: 5, life: 1.7, volley: true });
      }
      this.events.push({ kind: 'volley', playerId: player.id, x: player.x, y: player.y });
      return;
    }

    let healed = 0;
    for (const ally of this.players.values()) {
      if (!ally.dead && !ally.downed && distance(player, ally) <= 340 && ally.hp < ally.maxHp) {
        const amount = Math.min(46, ally.maxHp - ally.hp);
        ally.hp += amount;
        healed += amount;
        this.events.push({ kind: 'heal', playerId: ally.id, amount: Math.round(amount), x: ally.x, y: ally.y });
      }
    }
    player.ultimate = clamp(player.ultimate + healed * 0.16, 0, 100);
    this.events.push({ kind: 'healPulse', playerId: player.id, x: player.x, y: player.y, healed });
  }

  useUltimate(player) {
    player.ultimate = 0;
    this.events.push({ kind: 'ultimate', playerId: player.id, classId: player.classId, x: player.x, y: player.y });

    if (player.classId === 'guardian') {
      for (const ally of this.players.values()) {
        if (!ally.dead && !ally.downed) ally.shieldTime = Math.max(ally.shieldTime, 8);
      }
      if (distance(player, this.boss) <= 520) this.damageBoss(110, player, true);
      return;
    }

    if (player.classId === 'ranger') {
      for (let i = 0; i < 21; i += 1) {
        const angle = player.angle + (i - 10) * 0.067;
        this.spawnFriendlyProjectile(player, angle, 31, 1180, { radius: 6, life: 1.9, volley: true, ultimate: true });
      }
      return;
    }

    for (const ally of this.players.values()) {
      if (ally.dead) continue;
      if (ally.downed) {
        ally.downed = false;
        ally.hp = Math.round(ally.maxHp * 0.38);
        ally.bleedout = 0;
        ally.reviveProgress = 0;
        player.revives += 1;
        this.events.push({ kind: 'revive', playerId: ally.id, x: ally.x, y: ally.y });
      } else {
        const amount = Math.min(78, ally.maxHp - ally.hp);
        ally.hp += amount;
        if (amount > 0) this.events.push({ kind: 'heal', playerId: ally.id, amount: Math.round(amount), x: ally.x, y: ally.y });
      }
      ally.shieldTime = Math.max(ally.shieldTime, 3);
    }
    if (distance(player, this.boss) <= 700) this.damageBoss(85, player, true);
  }

  spawnFriendlyProjectile(player, angle, damage, speed, options = {}) {
    this.projectiles.push({
      id: this.entityId++,
      friendly: true,
      ownerId: player.id,
      classId: player.classId,
      x: player.x + Math.cos(angle) * (player.radius + 12),
      y: player.y + Math.sin(angle) * (player.radius + 12),
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      radius: options.radius || 5,
      damage,
      life: options.life || 1.8,
      volley: Boolean(options.volley),
      ultimate: Boolean(options.ultimate)
    });
  }

  spawnEnemyProjectile(angle, speed, damage, options = {}) {
    this.projectiles.push({
      id: this.entityId++,
      friendly: false,
      x: options.x ?? this.boss.x,
      y: options.y ?? this.boss.y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      radius: options.radius || 9,
      damage,
      life: options.life || 5,
      color: options.color || this.config.color
    });
  }

  updateProjectiles(dt) {
    const remaining = [];
    for (const projectile of this.projectiles) {
      projectile.x += projectile.vx * dt;
      projectile.y += projectile.vy * dt;
      projectile.life -= dt;
      let hit = false;

      if (projectile.friendly) {
        if (this.boss.hp > 0 && distance(projectile, this.boss) <= projectile.radius + this.boss.radius) {
          const owner = this.players.get(projectile.ownerId);
          if (owner) this.damageBoss(projectile.damage, owner);
          hit = true;
        }
      } else {
        for (const player of this.players.values()) {
          if (player.dead || player.downed) continue;
          if (distance(projectile, player) <= projectile.radius + player.radius) {
            this.damagePlayer(player, projectile.damage);
            hit = true;
            break;
          }
        }
      }

      const outside = projectile.x < -80 || projectile.y < -80 || projectile.x > WORLD.width + 80 || projectile.y > WORLD.height + 80;
      if (!hit && projectile.life > 0 && !outside) remaining.push(projectile);
    }
    this.projectiles = remaining;
  }

  updateBoss(dt) {
    const boss = this.boss;
    if (this.time < 3.2) {
      boss.attackCooldown = 2.1;
      return;
    }
    if (boss.stunTime > 0) {
      boss.stunTime = Math.max(0, boss.stunTime - dt);
      boss.attackCooldown = Math.max(boss.attackCooldown, 0.8);
      return;
    }
    boss.stagger = Math.max(0, boss.stagger - dt * 3.5);
    boss.attackCooldown -= dt;
    boss.basicCooldown -= dt;
    boss.castLock = Math.max(0, boss.castLock - dt);
    boss.targetTimer -= dt;

    const ratio = boss.hp / boss.maxHp;
    const nextPhase = ratio > 0.66 ? 1 : ratio > 0.32 ? 2 : 3;
    if (nextPhase !== boss.phase) {
      boss.phase = nextPhase;
      boss.attackCooldown = Math.min(boss.attackCooldown, 0.85);
      this.events.push({ kind: 'phase', phase: nextPhase, x: boss.x, y: boss.y });
    }

    const living = [...this.players.values()].filter((player) => !player.dead && !player.downed);
    if (!living.length) return;

    let target = this.players.get(boss.targetId);
    if (boss.targetTimer <= 0 || !target || target.dead || target.downed) {
      target = living.reduce((nearest, player) => (!nearest || distance(boss, player) < distance(boss, nearest) ? player : nearest), null);
      boss.targetId = target.id;
      boss.targetTimer = randomBetween(1.2, 2.4);
    }

    const dist = distance(boss, target);
    const targetAngle = Math.atan2(target.y - boss.y, target.x - boss.x);
    boss.angle = targetAngle;

    if (boss.castLock <= 0) {
      const preferredDistance = this.bossId === 'anubis' ? 260 : 150;
      if (dist > preferredDistance) {
        const phaseSpeed = 1 + (boss.phase - 1) * 0.13;
        boss.x += Math.cos(targetAngle) * this.config.speed * phaseSpeed * dt;
        boss.y += Math.sin(targetAngle) * this.config.speed * phaseSpeed * dt;
        boss.x = clamp(boss.x, 90, WORLD.width - 90);
        boss.y = clamp(boss.y, 90, WORLD.height - 90);
      }

      if (dist < boss.radius + target.radius + 35 && boss.basicCooldown <= 0) {
        boss.basicCooldown = Math.max(0.75, 1.35 - boss.phase * 0.12);
        this.damagePlayer(target, this.config.damage * 0.62);
        this.events.push({ kind: 'bossSwipe', x: boss.x, y: boss.y, angle: boss.angle });
      }

      if (boss.attackCooldown <= 0) {
        this.chooseBossAttack(target);
        boss.attackCooldown = randomBetween(2.3, 3.15) - (boss.phase - 1) * 0.28;
      }
    }
  }

  chooseBossAttack(target) {
    let choices;
    if (this.bossId === 'minotaur') {
      choices = this.boss.phase === 1 ? ['charge', 'slam', 'quake'] : ['charge', 'slam', 'quake', 'charge'];
    } else if (this.bossId === 'anubis') {
      choices = this.boss.phase === 1 ? ['judgment', 'scarabs', 'beams'] : ['judgment', 'scarabs', 'beams', 'sandstorm'];
    } else {
      choices = this.boss.phase === 1 ? ['pounce', 'howl', 'frost'] : ['pounce', 'howl', 'frost', 'charge'];
    }
    let attack = choices[Math.floor(Math.random() * choices.length)];
    if (attack === this.lastAttack && choices.length > 1) {
      attack = choices[(choices.indexOf(attack) + 1 + Math.floor(Math.random() * (choices.length - 1))) % choices.length];
    }
    this.lastAttack = attack;

    const boss = this.boss;
    const phase = boss.phase;
    const living = [...this.players.values()].filter((player) => !player.dead && !player.downed);
    this.events.push({ kind: 'bossAttack', attack, bossId: this.bossId, x: boss.x, y: boss.y });

    if (attack === 'charge') {
      const angle = Math.atan2(target.y - boss.y, target.x - boss.x);
      const delay = phase === 3 ? 0.85 : 1.15;
      this.addTelegraph({ kind: 'line', x: boss.x, y: boss.y, angle, length: 940, width: 112, delay, damage: 28 + phase * 3, effect: 'charge' });
      boss.castLock = delay + 0.3;
      return;
    }

    if (attack === 'slam') {
      const delay = 1.2;
      this.addTelegraph({ kind: 'circle', x: boss.x, y: boss.y, radius: 205 + phase * 18, delay, damage: 25 + phase * 3, effect: 'slam' });
      if (phase === 3) {
        this.addTelegraph({ kind: 'ring', x: boss.x, y: boss.y, inner: 220, outer: 390, delay: delay + 0.65, damage: 24, effect: 'slam' });
      }
      boss.castLock = delay + 0.25;
      return;
    }

    if (attack === 'quake' || attack === 'judgment' || attack === 'frost') {
      const settings = {
        quake: { radius: 104, delay: 1.25, damage: 24 },
        judgment: { radius: 112, delay: 1.5, damage: 27 },
        frost: { radius: 126, delay: 1.65, damage: 25 }
      }[attack];
      const targets = living.length ? living : [target];
      targets.forEach((player, index) => {
        this.addTelegraph({
          kind: 'circle',
          x: clamp(player.x + (attack === 'frost' ? randomBetween(-75, 75) : 0), 100, WORLD.width - 100),
          y: clamp(player.y + (attack === 'frost' ? randomBetween(-75, 75) : 0), 100, WORLD.height - 100),
          radius: settings.radius + (phase === 3 ? 18 : 0),
          delay: settings.delay + index * 0.12,
          damage: settings.damage + phase * 2,
          effect: attack
        });
      });
      if (attack === 'frost' && phase >= 2) {
        this.addTelegraph({ kind: 'circle', x: randomBetween(220, WORLD.width - 220), y: randomBetween(180, WORLD.height - 180), radius: 145, delay: 1.9, damage: 25, effect: 'frost' });
      }
      boss.castLock = settings.delay * 0.75;
      return;
    }

    if (attack === 'sandstorm') {
      this.addTelegraph({ kind: 'ring', x: boss.x, y: boss.y, inner: 150, outer: 440, delay: 1.65, damage: 31, effect: 'sandstorm' });
      boss.castLock = 1.5;
      return;
    }

    if (attack === 'beams') {
      const base = randomBetween(0, Math.PI);
      const count = phase === 3 ? 3 : 2;
      for (let i = 0; i < count; i += 1) {
        this.addTelegraph({ kind: 'line', x: boss.x, y: boss.y, angle: base + (Math.PI * i) / count, length: 1200, width: 82, delay: 1.35, damage: 27, effect: 'beam' });
      }
      boss.castLock = 1.35;
      return;
    }

    if (attack === 'pounce') {
      const delay = phase === 3 ? 0.85 : 1.15;
      this.addTelegraph({ kind: 'circle', x: target.x, y: target.y, radius: 152, delay, damage: 31 + phase * 2, effect: 'pounce' });
      boss.castLock = delay + 0.25;
      return;
    }

    if (attack === 'scarabs' || attack === 'howl') {
      const count = (attack === 'scarabs' ? 10 : 14) + phase * 2;
      const offset = randomBetween(0, TAU);
      for (let i = 0; i < count; i += 1) {
        this.spawnEnemyProjectile(offset + (TAU * i) / count, attack === 'scarabs' ? 270 : 330, attack === 'scarabs' ? 13 : 15, {
          radius: attack === 'scarabs' ? 8 : 10,
          life: 5
        });
      }
      if (attack === 'howl' && phase === 3) {
        living.forEach((player) => {
          const angle = Math.atan2(player.y - boss.y, player.x - boss.x);
          this.spawnEnemyProjectile(angle, 420, 17, { radius: 11, life: 4 });
        });
      }
      boss.castLock = 0.65;
    }
  }

  addTelegraph(data) {
    this.telegraphs.push({
      id: this.entityId++,
      elapsed: 0,
      resolved: false,
      ...data
    });
  }

  updateTelegraphs(dt) {
    const remaining = [];
    for (const telegraph of this.telegraphs) {
      telegraph.elapsed += dt;
      if (!telegraph.resolved && telegraph.elapsed >= telegraph.delay) {
        telegraph.resolved = true;
        this.resolveTelegraph(telegraph);
      }
      if (telegraph.elapsed < telegraph.delay + 0.32) remaining.push(telegraph);
    }
    this.telegraphs = remaining;
  }

  resolveTelegraph(telegraph) {
    for (const player of this.players.values()) {
      if (player.dead || player.downed) continue;
      let hit = false;
      if (telegraph.kind === 'circle') {
        hit = distance(player, telegraph) <= telegraph.radius + player.radius * 0.35;
      } else if (telegraph.kind === 'ring') {
        const dist = distance(player, telegraph);
        hit = dist >= telegraph.inner - player.radius * 0.3 && dist <= telegraph.outer + player.radius * 0.3;
      } else if (telegraph.kind === 'line') {
        const endX = telegraph.x + Math.cos(telegraph.angle) * telegraph.length;
        const endY = telegraph.y + Math.sin(telegraph.angle) * telegraph.length;
        const segmentX = endX - telegraph.x;
        const segmentY = endY - telegraph.y;
        const lengthSquared = segmentX * segmentX + segmentY * segmentY;
        const t = clamp(((player.x - telegraph.x) * segmentX + (player.y - telegraph.y) * segmentY) / lengthSquared, 0, 1);
        const closestX = telegraph.x + segmentX * t;
        const closestY = telegraph.y + segmentY * t;
        hit = Math.hypot(player.x - closestX, player.y - closestY) <= telegraph.width / 2 + player.radius * 0.35;
      }
      if (hit) this.damagePlayer(player, telegraph.damage);
    }

    if (telegraph.effect === 'charge') {
      const travel = Math.min(520, telegraph.length * 0.6);
      this.boss.x = clamp(telegraph.x + Math.cos(telegraph.angle) * travel, 85, WORLD.width - 85);
      this.boss.y = clamp(telegraph.y + Math.sin(telegraph.angle) * travel, 85, WORLD.height - 85);
    } else if (telegraph.effect === 'pounce') {
      this.boss.x = clamp(telegraph.x, 85, WORLD.width - 85);
      this.boss.y = clamp(telegraph.y, 85, WORLD.height - 85);
    }

    this.events.push({ kind: 'impact', effect: telegraph.effect, shape: telegraph.kind, x: telegraph.x, y: telegraph.y, radius: telegraph.radius || telegraph.outer || 120 });
  }

  resolveCollisions() {
    const players = [...this.players.values()].filter((player) => !player.dead);
    for (const player of players) {
      const dx = player.x - this.boss.x;
      const dy = player.y - this.boss.y;
      const dist = Math.hypot(dx, dy);
      const minimum = this.boss.radius + player.radius + 5;
      if (dist < minimum) {
        const angle = dist > 0.001 ? Math.atan2(dy, dx) : player.angle + Math.PI;
        player.x = clamp(this.boss.x + Math.cos(angle) * minimum, 42 + player.radius, WORLD.width - 42 - player.radius);
        player.y = clamp(this.boss.y + Math.sin(angle) * minimum, 42 + player.radius, WORLD.height - 42 - player.radius);
        player.vx *= 0.55;
        player.vy *= 0.55;
      }
    }

    const active = players.filter((player) => !player.downed);
    for (let i = 0; i < active.length; i += 1) {
      for (let j = i + 1; j < active.length; j += 1) {
        const a = active[i];
        const b = active[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy);
        const minimum = a.radius + b.radius + 3;
        if (dist > 0.001 && dist < minimum) {
          const push = (minimum - dist) * 0.5;
          const nx = dx / dist;
          const ny = dy / dist;
          a.x = clamp(a.x - nx * push, 42 + a.radius, WORLD.width - 42 - a.radius);
          a.y = clamp(a.y - ny * push, 42 + a.radius, WORLD.height - 42 - a.radius);
          b.x = clamp(b.x + nx * push, 42 + b.radius, WORLD.width - 42 - b.radius);
          b.y = clamp(b.y + ny * push, 42 + b.radius, WORLD.height - 42 - b.radius);
        }
      }
    }
  }

  updateRevives(dt) {
    for (const player of this.players.values()) {
      if (!player.downed || player.dead) continue;
      const helpers = [...this.players.values()].filter((ally) => (
        ally.id !== player.id && !ally.dead && !ally.downed && ally.input?.interact && distance(ally, player) <= 105
      ));
      if (helpers.length) {
        player.reviveProgress += dt * (1 + (helpers.length - 1) * 0.35);
        if (player.reviveProgress >= 2.2) {
          player.downed = false;
          player.hp = Math.round(player.maxHp * 0.42);
          player.bleedout = 0;
          player.reviveProgress = 0;
          helpers.forEach((helper) => { helper.revives += 1; });
          this.events.push({ kind: 'revive', playerId: player.id, x: player.x, y: player.y });
        }
      } else {
        player.reviveProgress = Math.max(0, player.reviveProgress - dt * 0.55);
      }
    }
  }

  damageBoss(amount, player, ultimateAttack = false) {
    if (this.boss.hp <= 0) return;
    const multiplier = this.boss.stunTime > 0 ? 1.25 : 1;
    const actual = Math.min(amount * multiplier, this.boss.hp);
    this.boss.hp = Math.max(0, this.boss.hp - actual);
    player.damageDone += actual;
    if (!ultimateAttack) player.ultimate = clamp(player.ultimate + actual * 0.11, 0, 100);

    if (this.boss.stunTime <= 0 && this.boss.hp > 0) {
      this.boss.stagger = clamp(this.boss.stagger + actual * 0.085, 0, 100);
      if (this.boss.stagger >= 100) {
        this.boss.stagger = 0;
        this.boss.stunTime = 3;
        this.boss.castLock = 0;
        this.telegraphs = [];
        this.events.push({ kind: 'stagger', x: this.boss.x, y: this.boss.y });
      }
    }
    this.events.push({ kind: 'bossHit', playerId: player.id, amount: Math.round(actual), x: this.boss.x + randomBetween(-25, 25), y: this.boss.y - this.boss.radius * 0.5 });
  }

  damagePlayer(player, amount) {
    if (player.dead || player.downed || player.dashTime > 0) return;
    const trainingMultiplier = this.players.size === 1 ? 0.82 : 1;
    const actual = Math.max(1, Math.round(amount * trainingMultiplier * (player.shieldTime > 0 ? 0.45 : 1)));
    player.hp = Math.max(0, player.hp - actual);
    player.ultimate = clamp(player.ultimate + actual * 0.32, 0, 100);
    this.events.push({ kind: 'playerHit', playerId: player.id, amount: actual, x: player.x, y: player.y });
    if (player.hp <= 0) {
      player.downed = true;
      player.bleedout = 20;
      player.reviveProgress = 0;
      player.downs += 1;
      this.events.push({ kind: 'playerDown', playerId: player.id, x: player.x, y: player.y });
    }
  }

  finish(outcome) {
    if (this.ended) return;
    this.ended = true;
    this.result = { outcome, duration: this.time };
    this.room.state = 'ended';
    this.room.result = this.result;
    this.events.push({ kind: outcome, duration: this.time, x: this.boss.x, y: this.boss.y });
  }

  snapshot() {
    return {
      bossId: this.bossId,
      world: this.world,
      decorSeed: this.decorSeed,
      time: this.time,
      result: this.result,
      boss: {
        x: this.boss.x,
        y: this.boss.y,
        angle: this.boss.angle,
        hp: Math.ceil(this.boss.hp),
        maxHp: this.boss.maxHp,
        radius: this.boss.radius,
        phase: this.boss.phase,
        stagger: this.boss.stagger,
        stunTime: this.boss.stunTime,
        targetId: this.boss.targetId
      },
      players: [...this.players.values()].map((player) => ({
        id: player.id,
        name: player.name,
        classId: player.classId,
        x: player.x,
        y: player.y,
        vx: player.vx,
        vy: player.vy,
        angle: player.angle,
        hp: Math.ceil(player.hp),
        maxHp: player.maxHp,
        radius: player.radius,
        attackCooldown: player.attackCooldown,
        abilityCooldown: player.abilityCooldown,
        dashCooldown: player.dashCooldown,
        dashTime: player.dashTime,
        shieldTime: player.shieldTime,
        stamina: player.stamina,
        maxStamina: player.maxStamina,
        sprinting: player.sprinting,
        ultimate: player.ultimate,
        downed: player.downed,
        dead: player.dead,
        bleedout: player.bleedout,
        reviveProgress: player.reviveProgress,
        damageDone: Math.round(player.damageDone),
        revives: player.revives,
        downs: player.downs
      })),
      projectiles: this.projectiles,
      telegraphs: this.telegraphs,
      events: this.events
    };
  }
}

module.exports = { Game };
