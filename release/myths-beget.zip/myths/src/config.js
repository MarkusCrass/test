const CLASSES = {
  guardian: {
    id: 'guardian',
    name: 'АРГОНАВТ',
    role: 'Защитник',
    maxHp: 190,
    speed: 250,
    radius: 23,
    damage: 29,
    attackRate: 0.46,
    attackRange: 120,
    ability: 'ЭГИДА',
    abilityDescription: 'Даёт отряду рядом щит на 4 секунды',
    abilityCooldown: 9,
    color: '#f1b45b'
  },
  ranger: {
    id: 'ranger',
    name: 'СЛЕДОПЫТ',
    role: 'Стрелок',
    maxHp: 125,
    speed: 290,
    radius: 20,
    damage: 19,
    attackRate: 0.27,
    projectileSpeed: 980,
    ability: 'СЕМЬ СТРЕЛ',
    abilityDescription: 'Выпускает веер из семи пробивающих стрел',
    abilityCooldown: 7,
    color: '#6fd7ae'
  },
  oracle: {
    id: 'oracle',
    name: 'ОРАКУЛ',
    role: 'Целитель',
    maxHp: 140,
    speed: 265,
    radius: 21,
    damage: 16,
    attackRate: 0.36,
    projectileSpeed: 760,
    ability: 'БАЛЬЗАМ',
    abilityDescription: 'Лечит союзников рядом и восстанавливает силы',
    abilityCooldown: 10,
    color: '#8ab8ff'
  }
};

const BOSSES = {
  minotaur: {
    id: 'minotaur',
    name: 'МИНОТАВР',
    epithet: 'Хозяин лабиринта',
    location: 'Крит, Греция',
    region: 'Эгейское море · 35.24° N, 25.13° E',
    threat: 'III',
    baseHp: 1850,
    speed: 112,
    radius: 57,
    damage: 22,
    color: '#df704b',
    ground: '#17201d',
    grid: '#29342c',
    fog: '#b67a50',
    image: '/assets/minotaur.jpg',
    lore: 'Лабиринт раскололся изнутри. Тот, кого считали мифом, вышел под открытое небо.',
    tip: 'Не стойте на линии рывка. После удара по земле босс уязвим.'
  },
  anubis: {
    id: 'anubis',
    name: 'АНУБИС',
    epithet: 'Весы последнего суда',
    location: 'Гиза, Египет',
    region: 'Долина царей · 29.98° N, 31.13° E',
    threat: 'IV',
    baseHp: 1650,
    speed: 96,
    radius: 52,
    damage: 20,
    color: '#d5ae55',
    ground: '#211e18',
    grid: '#3a3223',
    fog: '#c49754',
    image: '/assets/anubis.jpg',
    lore: 'Пески Гизы шепчут имена живых. Хранитель весов начал суд без приговорённых.',
    tip: 'Разбегайтесь при печатях суда и уходите из кольца песчаной бури.'
  },
  fenrir: {
    id: 'fenrir',
    name: 'ФЕНРИР',
    epithet: 'Пожиратель солнца',
    location: 'Ютунхеймен, Норвегия',
    region: 'Скандинавские горы · 61.63° N, 8.31° E',
    threat: 'V',
    baseHp: 2150,
    speed: 138,
    radius: 61,
    damage: 24,
    color: '#69a9d6',
    ground: '#142027',
    grid: '#263944',
    fog: '#6a9db5',
    image: '/assets/fenrir.jpg',
    lore: 'Цепь Глейпнир найдена оборванной. В норвежских горах снова слышен древний вой.',
    tip: 'Сохраняйте рывок для прыжка. В последней фазе не группируйтесь.'
  }
};

const WORLD = { width: 1600, height: 900 };

module.exports = { CLASSES, BOSSES, WORLD };
