import { build } from 'esbuild';
import { stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outfile = path.join(root, 'public', '3d.bundle.js');

await build({
  entryPoints: [path.join(root, 'public', 'renderer3d.js')],
  outfile,
  bundle: true,
  format: 'iife',
  globalName: 'Myths3D',
  minify: true,
  sourcemap: false,
  target: ['es2020'],
  legalComments: 'inline',
  define: { 'process.env.NODE_ENV': '"production"' }
});

const { size } = await stat(outfile);
console.log(`3D client bundled: ${(size / 1024).toFixed(0)} KiB (single classic script, no module requests).`);
